/**
 * @file letters_bag.cpp
 * @brief  Archivo de implementación del TDA LettersBag
 * @author Gonzalo Martínez Piédrola & Diego Ortega Sánchez
 */

#include "letters_bag.h"

using namespace
